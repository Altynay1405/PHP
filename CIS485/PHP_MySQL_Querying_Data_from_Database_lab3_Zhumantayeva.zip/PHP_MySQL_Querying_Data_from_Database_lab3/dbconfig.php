<?php

/* 
Connecting to MySQL steps
 */

$host = 'localhost';
$dbname = 'classicmodels';
$username = 'root';
$password = '';